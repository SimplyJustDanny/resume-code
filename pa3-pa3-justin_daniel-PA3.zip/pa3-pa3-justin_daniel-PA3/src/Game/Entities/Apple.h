#pragma once

#include "Entity.h"

class Apple: public Entity{
    public:
        Apple(int, int, int, int, ofImage);
};