#include "StrawberryPowerup.h"

void StrawberryPowerup::activate(Player *player){
    player->setEvade(true);
};