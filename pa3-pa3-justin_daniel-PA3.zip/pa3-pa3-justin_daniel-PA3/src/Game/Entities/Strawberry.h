#pragma once

#include "Entity.h"

class Strawberry: public Entity{
    public:
        Strawberry(int, int, int, int, ofImage);
};