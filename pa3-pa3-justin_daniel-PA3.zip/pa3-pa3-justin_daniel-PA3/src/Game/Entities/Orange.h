#pragma once

#include "Entity.h"

class Orange: public Entity{
    public:
        Orange(int, int, int, int, ofImage);
};