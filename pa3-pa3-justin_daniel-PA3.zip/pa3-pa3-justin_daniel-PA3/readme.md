Project 3 by Daniel Febles and Justin [REDACTED]
daniel.febles1@upr.edu
[REDACTED EMAIL]

All of the features from Project 2 are fully functional, and most of Project 3's features as well (excluding GPS, which only works half the time).

Please never do this again, I feel terrible.

### Rank properties:

| Powerup  | Rank |
| ---------|------|
|Random    |0     |
|Speed     |1     |
|Cherry    |2     |
|Strawberry|3     |
|Ultimate  |4     |

[NOTE: Random is Rank 0 as it activates immediately. Ultimate activates immediately too but is rank 4 due to superiority.]