#pragma once

#include "Entity.h"

class Galaga: public Entity{
    public:
        Galaga(int, int, int, int, ofImage);
};